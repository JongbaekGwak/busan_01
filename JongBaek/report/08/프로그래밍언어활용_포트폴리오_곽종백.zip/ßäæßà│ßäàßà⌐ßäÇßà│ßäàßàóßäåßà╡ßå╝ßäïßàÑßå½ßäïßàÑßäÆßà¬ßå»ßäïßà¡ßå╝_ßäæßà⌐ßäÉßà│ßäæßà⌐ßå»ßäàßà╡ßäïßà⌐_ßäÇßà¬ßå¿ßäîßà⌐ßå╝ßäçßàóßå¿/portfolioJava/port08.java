package portfolio;

public class port08 {

	public static void main(String[] args) {
		int num[] = new int[10];
		int max = 0;
		for (int i = 0; i < num.length; i++) {
			num[i] = (int) (Math.random() * 100) + 1;
			if (max < num[i]) {
				max = num[i];
			}
		}
		System.out.println(max);
	}

}
