package portfolio;

public class port01 {

	public static void main(String[] args) {
		int trap[] = new int[] { 5, 10, 7 };
		System.out.println("사다리꼴의 넓이를 구하시오");
		System.out.println("윗변 : " + trap[0]);
		System.out.println("아랫변 : " + trap[1]);
		System.out.println("높이 : " + trap[2]);
		System.out.println();
		double area = 0;
		area = (double) ((trap[0] + trap[1]) * trap[2]) / 2;
		System.out.println("사다리꼴의 넓이 구하는 방법 : {(윗변 + 아랫변) * 높이} / 2");
		System.out.println("사다리꼴의 넓이 : " + area);
	}

}
